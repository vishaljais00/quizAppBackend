const db = require("../Models");
const {responseJSON} = require("../helper/responce");
const { QueryTypes, where, Op , Sequelize} = require("sequelize");

// declaring the usermodel
const quizMaster = db.quizMaster;
const quizQuestion = db.quizQuestion;
const quizOption = db.quizOption;
const userQuizMasterModel = db.userQuizMasterModel;
const userQuizDetail = db.userQuizDetail;
const User = db.users;

exports.storeUserQuizMaster = async (req, res) => {
  try {
    const {quiz_master_id, user_start_time, total_question} = req.body;

    const findUserQuiz = await userQuizMasterModel.findOne({ 
      where: {
        user_id: req.user.user_id , 
        quiz_master_id, 
      }
  });

  if(findUserQuiz) return await responseJSON(res, 200, "user quiz already created", findUserQuiz);
    // created quiz
    const userCreatedQuiz = await userQuizMasterModel.create({ 
        user_id: req.user.user_id , 
        quiz_master_id, 
        user_start_time, 
        total_question,
        status: false
    });

    return await responseJSON(res, 200, "user quiz has been initiated", userCreatedQuiz);

  } catch (error) {
    return await responseJSON(res, 400, "something went wrong", error.message);
  }
};

exports.submitUserQuizMaster = async (req, res) => {
    try {
        const {user_quiz_master, answer, user_end_time} = req.body;
        let userQuizData = await userQuizMasterModel.findByPk(user_quiz_master);    //  1)  find user quiz
        if (userQuizData.status) return await responseJSON(res, 200, "quiz has been already submitted", userQuizData);
        let total_marks = 0;    //  2) calculate marks
        await Promise.all(answer.map(async (item, i) => {
            const questData = await quizQuestion.findByPk(item.quiz_question_id);
            const saveUserDetail = await userQuizDetail.create({
              user_id: req.user.user_id,
              quiz_master_id: user_quiz_master,
              quiz_question_id: item.quiz_question_id,
              user_answer: item.user_answer
            })
            if (questData.quiz_answer.trim() == item.user_answer.trim()) {
                total_marks += 1;
            } 
        }));

        userQuizData.user_end_time = user_end_time; // 3) calcutare total time taken
        userQuizData.total_marks = total_marks;
        userQuizData.total_time =  (new Date(user_end_time) - new Date(userQuizData.user_start_time))
        userQuizData.status = true
        await userQuizData.save()    //  3) save user entry
        return await responseJSON(res, 200, "user quiz submited", userQuizData);
  
    } catch (error) {
        return await responseJSON(res, 400, "something went wrong", error.message);
    }
  };

exports.getAllQuizResult = async (req, res) => {
    try {
      // created quiz
      const QuizAnswerList = await quizMaster.findAll({
        include: [
            {
                model: userQuizMasterModel,
                as: 'user_quiz_list',
                where: {
                  total_question : {
                    [Op.eq]: db.sequelize.col("total_marks")
                } 
              },
                include: [{
                  model: User,
                  as: 'quiz_user_detail',
                }],
                separate: true, order:[['total_marks', 'DESC'], ['total_time', 'ASC']],
                limit: 10
            }
        ]
      })
  
      return await responseJSON(res, 200, "quiz master list with result", QuizAnswerList);
  
    } catch (error) {
      return await responseJSON(res, 400, "something went wrong", error.message);
    }
  };

exports.getCombineResult = async (req, res) => {
  try {
    const QuizAnswerList = await userQuizMasterModel.findAll({
      attributes: [
        [
          db.sequelize.fn('SUM', db.sequelize.col('total_marks')),
          'total_marks2'
        ],
        [
          db.sequelize.fn('SUM', db.sequelize.col('total_time')),
          'total_time2'
        ],
        [
          db.sequelize.fn('SUM', db.sequelize.col('total_question')),
          'total_question'
        ],
        'quiz_user_detail.user_id',
        'quiz_user_detail.user_name',
        'quiz_user_detail.email',
        'quiz_user_detail.phone'
      ],
      include: [
        {
          model: User,
          as: 'quiz_user_detail'
        }
      ],
      where: {
        status: true
      },
      group: ['quiz_user_detail.user_id'],
      having: Sequelize.literal('total_marks2 = total_question'),
      order: [
        [Sequelize.literal('total_marks DESC')],
        [Sequelize.literal('total_time ASC')]
      ] 
    });

    return await responseJSON(res, 200, "combine result", QuizAnswerList);
  } catch (error) {
    return await responseJSON(res, 400, "something went wrong", error.message);
  }
}

exports.checkUserQuizMaster = async (req, res) => {
  try {
    const {id} = req.query;

    const findUserQuiz = await userQuizMasterModel.findOne({ 
      where: {
        user_id: req.user.user_id, 
        quiz_master_id: id, 
      }
  });

    return await responseJSON(res, 200, "user quiz status", findUserQuiz);

  } catch (error) {
    return await responseJSON(res, 400, "something went wrong", error.message);
  }
};

  